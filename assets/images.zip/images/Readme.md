# Image assets

This directory contains all the images used in the application. All images should be placed here.
