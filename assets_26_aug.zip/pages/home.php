<!-- Page Sections -->

    <section class="hero-section">
      <div class="container text-center scroll-section">
        <div class="hero-heading position-relative">
          <p>
            Unlock Growth With<br />
            Powerful Business Technology Solutions
            from <span class="hero-heading-effect">Mavix Tech</span>
          </p>
          <div
            class="position-absolute top-50 start-50 hero-bg-img translate-middle"
          >
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/banner-blur.svg"  class="home-tech-home-img"/>
          </div>
        </div>

        <div class="hero-btn d-flex gap-3 justify-content-center flex-wrap">
          
          <button class="blob-btn">
            Contact Us
            <span class="btn-learn-more-arrow ms-2"
              ><i class="bi bi-arrow-right"></i
            ></span>
            <span class="blob-btn__inner">
              <span class="blob-btn__blobs">
                <span class="blob-btn__blob"></span>
                <span class="blob-btn__blob"></span>
                <span class="blob-btn__blob"></span>
                <span class="blob-btn__blob"></span>
              </span>
            </span>
          </button>

          <!-- Goo Filter -->
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="animation-svg"
            version="1.1"
          >
            <defs>
              <filter id="goo">
                <feGaussianBlur
                  in="SourceGraphic"
                  result="blur"
                  stdDeviation="10"
                ></feGaussianBlur>
                <feColorMatrix
                  in="blur"
                  mode="matrix"
                  values="
            1 0 0 0 0
            0 1 0 0 0
            0 0 1 0 0
            0 0 0 21 -7
        "
                  result="goo"
                ></feColorMatrix>
                <feBlend in="SourceGraphic" in2="goo" result="mix"></feBlend>
              </filter>
            </defs>
          </svg>
        </div>

        <div class="hero-text">
          Grow your business with innovative Business Technology Solutions designed to match your needs.
        </div>

        <div class="hero-image">
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/DHL.png" alt="DHL" />
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/AMEX.png" alt="Amex" />
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Microsoft.png" alt="Microsoft" />
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Nhl.png" alt="NHL" />
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Wikipedia.png" alt="Wikipedia" />
        </div>
      </div>
    </section>

    <section class="">
      <div class="container py-5 ai-driven">
        <div class="section-heading scroll-section section-padding" >
          <p class="mainheading-global">
            Ignite Your <span class="mainheding-color">Business Growth </span> with
            Powerful Business Technology <br class="d-none d-md-block" /> Solutions
          </p>
          <p class="subtitle-contetn text-muted mt-4">
            Accelerate your digital success with innovative, scalable, and result-focused business technology solutions 
            designed to drive growth and <br
              class="d-none d-lg-block"
            />
            streamline your operations
          </p>
        </div>

        <div class="row text-center mt-5">
          <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div
              class="info-box scroll-section"
              data-animation="animate__fadeInUp"
              data-delay="0s"
            >
              <p class="ai-agnite-heading">01</p>
              <!-- <p class="ps-3 ai-agnite subcontainet-global fw-bold">
                
              </p> -->
              <p class="ps-3 ai-agnite subcontainet-global mt-2">
               Dedicated Expert Team Skilled professionals focused on delivering innovative, effective results for today’s competitive business landscape.
              </p>
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div
              class="info-box scroll-section"
              data-animation="animate__fadeInUp"
              data-delay="0.2s"
            >
              <p class="ai-agnite-heading">02</p>
              <!-- <p class="ps-3 ai-agnite subcontainet-global fw-bold">
               
              </p> -->
              <p class="ps-3 ai-agnite subcontainet-global mt-2">
               Scalable Infrastructure  Agile technology frameworks are built to evolve with your business and support sustainable growth.
              </p>
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div
              class="info-box scroll-section"
              data-animation="animate__fadeInUp"
              data-delay="0.4s"
            >
              <p class="ai-agnite-heading">03</p>
              <!-- <p class="ps-1 ai-agnite subcontainet-global fw-bold">
                
              </p> -->
              <p class="ps-1 ai-agnite subcontainet-global mt-2">
               Data-Driven Optimization Enhance efficiency and decision-making with strategic improvements powered by data intelligence.
              </p>
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div
              class="info-box scroll-section"
              data-animation="animate__fadeInUp"
              data-delay="0.6s"
            >
              <p class="ai-agnite-heading">04</p>
              <!-- <p class="ps-1 ai-agnite subcontainet-global fw-bold">
               
              </p> -->
              <p class="ps-1 ai-agnite subcontainet-global mt-2">
               Seamless Integration Capabilities  Effortlessly unify your systems with our Business Technology Solutions for smooth operational performance.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- shhopify scroll section -->

    <section>
      <div class="container text-center">
        <p class="phase-titele mainheading-global">
          <span class="br-toggle">Explore Our Core Services That </span>
          <span class="br-toggle">Power Digital Growth</span>
        </p>
        <p class="text-muted subtitle-contetn">
          <span class="br-toggle"
            >From building online stores to boosting brand visibility,</span
          >
          <span class="br-toggle"> our core services are built to drive business success.</span>
        </p>
      </div>

      <div class="container mt-4 custom-scroll-height">
        <a
          href="shopify-service.html"
          class="text-decoration-none text-dark scrollable-card"
        >
          <div class="row integration-card animate__animated shadow">
            <div
              class="col-lg-4 d-flex flex-column justify-content-center card-left"
            >
              <p class="mb-2 card-title ms-4 me-5">Shopify</p>
              <p class="mb-3 ms-4 me-4 integration-card-content">
                Boost speed, mobile usability, and sales with a high-performing Shopify storefront built for conversions.
              </p>
              <button
                class="btn btn-custom ms-3 align-self-lg-start align-self-center"
              >
              Learn More
              </button>
            </div>

            <div class="col-lg-8 p-0">
              <img
                src="<?php echo $config['WEB_PATH'] ?>assets/images/shopify.png"
                alt="Shopify"
                class="img-fluid feature-image "
              />
            </div>
          </div>
        </a>
        <a
          href="salesforces-service.html"
          class="text-decoration-none text-dark scrollable-card"
        >
          <div class="row integration-card animate__animated shadow">
            <div
              class="col-lg-4 d-flex flex-column justify-content-center card-left"
            >
              <h5 class="mb-2 card-title ms-4 me-5">Salesforce</h5>
              <p class="mb-3 ms-4 me-4 integration-card-content">
                Streamline CRM workflows and improve lead management to close deals faster and boost efficiency.
              </p>
              <button
                class="btn btn-custom ms-3 align-self-lg-start align-self-center"
              >
                Learn More
              </button>
            </div>
            <div class="col-lg-8 p-0">
              <img
                src="<?php echo $config['WEB_PATH'] ?>assets/images/salseforce.png"
                alt="Salesforce"
                class="img-fluid feature-image"
              />
            </div>
          </div>
        </a>

        <a
          href="email-marketing.html"
          class="text-decoration-none text-dark scrollable-card"
        >
          <div class="row integration-card animate__animated shadow">
            <div
              class="col-lg-4 d-flex flex-column justify-content-center card-left"
            >
              <h5 class="mb-2 card-title ms-4 me-5">Email Marketing</h5>
              <p class="mb-3 ms-4 me-4 integration-card-content">
                Increase sales with engaging, well-designed email campaigns that connect with your audience.
              </p>
              <button
                class="btn btn-custom ms-3 align-self-lg-start align-self-center"
              >
                Learn More
              </button>
            </div>
            <div class="col-lg-8 p-0">
              <img
                src="<?php echo $config['WEB_PATH'] ?>assets/images/emailmarkating.png"
                alt="Email Marketing"
                class="img-fluid feature-image"
              />
            </div>
          </div>
        </a>

        <a
          href="digital-marketing.html"
          class="text-decoration-none text-dark scrollable-card"
        >
          <div class="row integration-card animate__animated shadow">
            <div
              class="col-lg-4 d-flex flex-column justify-content-center card-left"
            >
              <h5 class="mb-2 card-title ms-4 me-5">Digital Marketing</h5>
              <p class="mb-3 ms-4 me-4 integration-card-content">
                Enhance your brand’s online presence and drive growth with targeted digital marketing strategies.
              </p>
              <button
                class="btn btn-custom ms-3 align-self-lg-start align-self-center"
              >
                Learn More
              </button>
            </div>
            <div class="col-lg-8 p-0">
              <img
                src="<?php echo $config['WEB_PATH'] ?>assets/images/digitalmarkating.png"
                alt="Digital Marketing"
                class="img-fluid feature-image"
              />
            </div>
          </div>
        </a>
      </div>
    </section>

    <section class="container py-5 transformative-main">
      <div class="scroll-section">
        <h2 class="section-title mainheading-global">
          <span class="mainheding-color">What Our Clients </span>Say About<br />
          Mavix Tech
        </h2>
        <p class="section-subtitle subtitle-contetn text-muted mt-4">
          Discover how Mavix Tech’s Business Technology Solutions have transformed businesses and fueled growth.
        </p>
      </div>

      <div class="d-flex flex-wrap p-2 p-lg-0 g-3 mt-5">
        <!-- Testimonial 1 -->
        <div class="col-md-6 col-lg-4 mb-2 mb-lg-0 p-0 p-lg-2">
          <div
            class="testimonial-card scroll-section"
            data-animation="animate__fadeInUp"
            data-delay="0s"
          >
            <div class="testimonial-quote mb-3">
              <img src="<?php echo $config['WEB_PATH']; ?><?php echo $config['WEB_PATH'] ?>assets/images/Vector.png" alt="" />
            </div>
            <p>
              Mavix Tech delivers innovative Business Technology Solutions designed to drive results across key industries.
            </p>
            <div class="client-info">
             
              <div class="d-block mt-4">
                <p class="user-name">Alex Johnson</p>
                <p class="user-detail">CTO at TechInnovate</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Testimonial 2 -->
        <div class="col-md-6 col-lg-4 mb-2 mb-lg-0 p-0 p-lg-2">
          <div
            class="testimonial-card scroll-section"
            data-animation="animate__fadeInUp"
            data-delay="0.1s"
          >
            <div class="testimonial-quote mb-3">
              <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Vector.png" alt="" />
            </div>
            <p>
              Mavix Tech transformed our outdated online store into a sleek,
              high-converting Shopify website. Their team was professional,
              fast,
            </p>
            <div class="client-info">
             
              <div class="d-block mt-4">
                <p class="user-name">Emily Davis</p>
                <p class="user-detail">Marketing Director at RetailPulse</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Testimonial 3 -->
        <div class="col-md-6 col-lg-4 mb-2 mb-lg-0 p-0 p-lg-2">
          <div
            class="testimonial-card scroll-section"
            data-animation="animate__fadeInUp"
            data-delay="0.2s"
          >
            <div class="testimonial-quote mb-3">
              <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Vector.png" alt="" />
            </div>
            <p>
              The email marketing campaigns Mavix Tech created were not only
              beautiful but highly effective. Our open rates improved by 45%.
            </p>
            <div class="client-info">
              
              <div class="d-block mt-4">
                <p class="user-name">Michael Lee</p>
                <p class="user-detail">CTO at TechInnovate</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>

    <!-- advanced features section -->
    <!--<section class="scroll-section">-->
    <!--  <div id="home-advanced-features" class=""></div>-->

    <!--  <div class="hero-btn d-flex gap-3 justify-content-center flex-wrap">-->
    <!--    <button class="btn btn-get-started">Get Started</button>-->
    <!--    <button-->
    <!--      class="btn btn-learn-more btn-learn-more-bottom blob-btn text-dark"-->
    <!--    >-->
    <!--      Learn More-->
    <!--      <span class="btn-learn-more-arrow ms-2"-->
    <!--        ><i class="bi bi-arrow-right"></i-->
    <!--      ></span>-->
    <!--      <span class="blob-btn__inner">-->
    <!--        <span class="blob-btn__blobs">-->
    <!--          <span class="blob-btn__blob"></span>-->
    <!--          <span class="blob-btn__blob"></span>-->
    <!--          <span class="blob-btn__blob"></span>-->
    <!--          <span class="blob-btn__blob"></span>-->
    <!--        </span>-->
    <!--      </span>-->
    <!--    </button>-->
    <!--  </div>-->
    <!--</section>-->

    <section class="container contact-container py-5">
      <div class="text-center mb-4 scroll-section">
        <h2 class="mainheading-global">
          <span class="mainheding-color">Contact</span> us
        </h2>
        <p class="text-muted subtitle-contetn">
          We’re here to help you share your thoughts or<br />
          inquiries with us, and we’ll get back to you <br />
          soon!
        </p>
      </div>
      <div class="row g-lg-4 d-flex align-items-start">
        <!-- Image -->
        <div class="col-md-3 text-center">
          <img
            src="<?php echo $config['WEB_PATH'] ?>assets/images/woman.png"
            alt="Woman with tablet"
            class="img-fluid rounded-4 shadow-sm scroll-section"
            data-animation="animate__fadeInUp"
            data-delay="0s"
          />
          <div
            class="card-custom mt-3 text-start scroll-section"
            data-animation="animate__fadeInUp"
            data-delay="0.1s"
          >
            <img
              src="<?php echo $config['WEB_PATH'] ?>assets/images/location.png"
              alt="Location icon"
              class="mb-2"
            />
            <p class="mb-1 text-muted">Location</p>
            <small>Office: 123 Maple Street, Springfield</small>
          </div>
        </div>

        <!-- Contact Form -->
        <div class="col-md-6 flex-fill align-self-stretch">
          <div
            class="card-custom d-flex flex-column h-100 position-relative scroll-section"
            data-animation="animate__fadeInUp"
            data-delay="0.1s"
          >
            <form class="p-4 pt-5">
              <div class="mb-4">
                <label class="form-label small text-muted">NAME</label>
                <input type="text" class="form-control" value="" />
              </div>
              <div class="mb-4">
                <label class="form-label small text-muted">EMAIL</label>
                <input
                  type="email"
                  class="form-control"
                  value=""
                />
              </div>
              <div class="mb-4">
                <label class="form-label small text-muted">MESSAGE</label>
                <textarea class="form-control" rows="6" placeholder="Draft a message"
  onfocus="this.placeholder=''"
  onblur="if(this.value===''){this.placeholder='Draft a message'}"></textarea
                >
              </div>
              <button type="submit" class="btn btn-custom px-4">
                Send Message
              </button>
            </form>
            <div
              class="position-absolute arrow-custom top-100 start-70 translate-middle"
            >
              <img
                src="<?php echo $config['WEB_PATH'] ?>assets/images/letter_send 1.png"
                alt="Arrow pointing to form"
                class="img-fluid arrow-image"
              />
            </div>
          </div>
        </div>

        <!-- Contact Info -->
        <div class="col-md-3 flex-fill align-self-stretch">
          <div class="d-flex flex-column h-100 justify-content-between">
            <div
              class="card-custom mb-3 flex-grow-1 scroll-section"
              data-animation="animate__fadeInUp"
              data-delay="0.1s"
            >
              <img src="<?php echo $config['WEB_PATH'] ?>assets/images/sms.png" alt="Phone icon" class="mb-2" />
              <div class="mb-2"><strong>Email</strong></div>
              <p class="text-muted mb-0 text-break">info@mavixtech.com</p>
            </div>
            <div
              class="card-custom mb-3 flex-grow-1 scroll-section"
              data-animation="animate__fadeInUp"
              data-delay="0.1s"
            >
              <img
                src="<?php echo $config['WEB_PATH'] ?>assets/images/call.png"
                alt="Phone icon"
                class="mb-2"
              />
              <div class="mb-2"><strong>Phone</strong></div>
              <p class="text-muted mb-0">Office: 6232 1151 261</p>
            </div>
          </div>
        </div>
      </div>
    </section>