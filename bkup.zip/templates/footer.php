
    <footer class="footer position-relative">
      <div class="container">
        <div class="row">
          <div class="col-12 col-md-6 col-lg-6 mb-5">
            <div class="logo mb-3">
              <img
                src="assets/images/mavix_Logo.png"
                alt="Logo"
                class="nav-logo-img"
              />
            </div>
            <!-- <p class="mt-4 footer-font logo-content">
              Sparkly is your gateway to expert-led, accessible learning.
              Empowering you with skills to succeed in a fast-changing world, we
              offer courses designed to help you grow and achieve your goals at
              your own pace.
            </p> -->
            <div class="back-to-top footer-font mt-5">
              <span class="me-2">Back to top</span>
              <a href="#" class="btn btn-light btn-sm">↑</a>
            </div>
          </div>

          <div class="col-12 col-md-6 col-lg-2 mb-5">
            <div class="mt-4">
              <h5 class="footer-font-heading">Company</h5>
              <ul
                class="list-unstyled footer-font d-flex flex-column gap-3 mt-4"
              >
                <li>
                  <a href="#" class="text-white text-decoration-none">Home</a>
                </li>
                <li>
                  <a href="#" class="text-white text-decoration-none"
                    >Mentors</a
                  >
                </li>
                <li>
                  <a href="#" class="text-white text-decoration-none"
                    >About us</a
                  >
                </li>
              </ul>
            </div>
          </div>

          <div class="col-12 col-md-6 col-lg-2 mb-5">
            <div class="mt-4">
              <h5 class="footer-font-heading">Support</h5>
              <ul
                class="list-unstyled footer-font d-flex flex-column gap-3 mt-4"
              >
                <li>
                  <a href="#" class="text-white text-decoration-none"
                    >Contact us</a
                  >
                </li>
                <li>
                  <a href="#" class="text-white text-decoration-none">Blogs</a>
                </li>
              </ul>
            </div>
          </div>

          <div class="col-12 col-md-6 col-lg-2 mb-5">
            <div class="mt-4">
              <h5 class="footer-font-heading">Courses</h5>
              <ul
                class="list-unstyled footer-font d-flex flex-column gap-3 mt-4"
              >
                <li>
                  <a href="#" class="text-white text-decoration-none"
                    >UI/UX Designing</a
                  >
                </li>
                <li>
                  <a href="#" class="text-white text-decoration-none"
                    >Web Development</a
                  >
                </li>
                <li>
                  <a href="#" class="text-white text-decoration-none"
                    >Data Visualization</a
                  >
                </li>
                <li>
                  <a href="#" class="text-white text-decoration-none"
                    >Digital Marketing</a
                  >
                </li>
                <li>
                  <a href="#" class="text-white text-decoration-none">AI/ML</a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <hr class="my-4 mb-5" />

        <div
          class="d-flex flex-column flex-md-row justify-content-between align-items-center"
        >
          <p class="mb-2 mb-md-0 footer-font">
            © Sparkly Inc. All Rights Reserved.
          </p>
          <ul class="footer-social-media-ul social-icons">
            <li>
              <a href="#"><i class="bi bi-twitter-x icon"></i></a>
            </li>
            <li>
              <a href="#"><i class="bi bi-facebook icon"></i></a>
            </li>
            <li>
              <a href="#"><i class="bi bi-instagram icon"></i></a>
            </li>
            <li>
              <a href="#"><i class="bi bi-linkedin icon"></i></a>
            </li>
          </ul>
        </div>
      </div>

      <img
        src="assets/images/Ellipse.png"
        alt="Background Glow"
        class="ellipse-img left-img"
      />
      <img
        src="assets/images/Ellipse.png"
        alt="Background Glow"
        class="ellipse-img right-img"
      />
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery and Slick -->

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <!-- Dynamic content loader -->
    <script src="<?php echo $config['WEB_PATH']; ?>assets/js/homepage/home.js" defer></script>

    <!-- Scroll animation script (reusable) -->
    <script type="module">
      import { initScrollAnimations } from "<?php echo $config['WEB_PATH']; ?>assets/utils/scroll-animations.js";

      window.addEventListener("DOMContentLoaded", () => {
        initScrollAnimations(); // you can pass options here if needed
      });
    </script>
</body>
</html>