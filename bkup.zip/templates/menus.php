  <nav class="navbar navbar-expand-lg text-white px-md-0 sticky-top">
      <div class="container nav-main">
        <a class="navbar-brand" href="<?php echo $config['SITE_URL'] ?>">
          <div class="navbar-logo">
            <img
              src="assets/images/mavix_Logo.png"
              alt="Logo"
              class="nav-logo-img"
            />
          </div>
        </a>

        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="offcanvas"
          data-bs-target="#navbarOffcanvas"
          aria-controls="navbarOffcanvas"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Replace the collapse div with offcanvas -->
        <div
          class="offcanvas offcanvas-end"
          tabindex="-1"
          id="navbarOffcanvas"
          aria-labelledby="navbarOffcanvasLabel"
        >
          <div class="offcanvas-header">
            <h5 class="offcanvas-title text-white" id="navbarOffcanvasLabel">
              Menu
            </h5>
            <button
              type="button"
              class="btn-close text-reset"
              data-bs-dismiss="offcanvas"
              aria-label="Close"
            ></button>
          </div>
          <div class="offcanvas-body justify-content-end">
            <div class="navbar-nav align-items-center">
              <a class="nav-link toggled-nav-items" href="<?php echo $config['SITE_URL'] ?>">Home</a>

              <!-- Dropdown for Services -->
              <div class="nav-item dropdown d-none d-lg-block">
                <a
                  class="nav-link dropdown-toggle toggled-nav-items"
                  href="#menu"
                  id="servicesDropdown"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Services
                </a>
                <ul class="dropdown-menu" aria-labelledby="servicesDropdown">
                  <li class="dropdownmenu-item">
                    <a class="dropdown-item" href="?p=shopify-service"
                      >Shopify</a
                    >
                  </li>
                  <li class="dropdownmenu-item">
                    <a class="dropdown-item" href="?p=salesforces-service"
                      >Salseforce</a
                    >
                  </li>
                  <li class="dropdownmenu-item">
                    <a class="dropdown-item" href="?p=email-marketing"
                      >Email Markaing</a
                    >
                  </li>
                  <li>
                    <a class="dropdown-item" href="?p=digital-marketing"
                      >Digital Markating</a
                    >
                  </li>
                </ul>
              </div>

              <div
                class="accordion nav-accordion d-block d-lg-none toggled-nav-items"
                id="navAccordion"
              >
                <div class="accordion-item border-0 shadow-sm mb-2">
                  <h2 class="accordion-header" id="headingOne">
                    <button
                      class="accordion-button mainsubheading-global"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#collapseOne"
                      aria-expanded="false"
                      aria-controls="collapseOne"
                    >
                      Services
                    </button>
                  </h2>
                  <div
                    id="collapseOne"
                    class="accordion-collapse collapse"
                    aria-labelledby="headingOne"
                    data-bs-parent="#navAccordion"
                  >
                    <div
                      class="accordion-body frequently-cont mainsubheading-global"
                    >
                      <ul class="list-unstyled ps-0 mb-0">
                        <li class="my-2">
                          <a
                            class="text-decoration-none text-dark"
                            href="?p=shopify-service"
                            >Shopify</a
                          >
                        </li>
                        <li class="my-2">
                          <a
                            class="text-decoration-none text-dark"
                            href="?p=salesforces-service"
                            >Salesforce</a
                          >
                        </li>
                        <li class="my-2">
                          <a
                            class="text-decoration-none text-dark"
                            href="?p=email-marketing"
                            >Email Marketing</a
                          >
                        </li>
                        <li class="my-2">
                          <a
                            class="text-decoration-none text-dark"
                            href="?p=digital-marketing"
                            >Digital Marketing</a
                          >
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <a class="nav-link toggled-nav-items" href="?p=features">Blog</a>
              <a class="nav-link toggled-nav-items" href="?p=contact-us"
                >Contact Us</a
              >
              <a
                href="?p=order"
                class="navbar-btn px-4 py-2 rounded-pill btn-brand ms-lg-3 mt-3 mt-lg-0"
                >Order Now</a
              >
            </div>
          </div>
        </div>
      </div>
    </nav>