
  <section class="">
    <!-- <div id="home-header"></div> -->

    <div class="hero-section overflow-hidden">
      <div class="container text-center scroll-section">
        <div class="hero-heading position-relative">
          <p>
            Professional
            <span class="hero-heading-effect">Email </span> <br> <span class="hero-heading-effect">Markating
            </span>Development <br> Company
          </p>
          <div class="position-absolute top-80 start-50 email-hero-bg-img translate-middle">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/homepage-hero-bg-gradient.png" class="email-tech-home-img">
          </div>
        </div>


        <p class="text-light mt-3 mb-4  email-marketing-hero-subtext">
          Stand out with beautifully designed, mobile-friendly email marketing services from a trusted email template
          development company that drive real engagement and boost your brand visibility. Let us help you connect with
          your audience effectively.
        </p>

        <form class="email-form z-1 position-relative">
          <input type="email" placeholder="Email address" required />
          <button type="submit">Get started</button>
        </form>

        <!-- <div class="hero-text">
          <p> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
        </div> -->

        <div class="hero-image mt-5">
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/DHL.png" alt="DHL">
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/AMEX.png" alt="Amex">
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Microsoft.png" alt="Microsoft">
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Nhl.png" alt="NHL">
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Wikipedia.png" alt="Wikipedia">
        </div>
      </div>
    </div>
  </section>


  <section class="scroll-section">
    <div class="container py-5">
      <div class="row">
        <div class="col-lg-6 scroll-section" data-animation="animate__fadeInUp" data-delay="0s">
          <div class="email-marketing">
            <p class="mainheading-global position-relative z-1">Crafting <span class="mainheding-color">Visually</span>
              Stunning <br class="d-none d-md-block"> Email
              Templates That Convert
              <img src="<?php echo $config['WEB_PATH'] ?>assets/images/ShopifyDevlopment.png"
                class="position-absolute img-fluid emailmarkating-visually-img service-img-header z-1"
                alt="Highlight Underline">
            </p>
            <p class="email-marketing-content emailmarkating-subcintent">We design engaging, mobile-friendly
              email templates that enhance
              your brand and increase customer interaction.</p>


            <div class="d-flex justify-content-start align-items-start gap-2">
              <img src="<?php echo $config['WEB_PATH'] ?>assets/images/RightSine.png">
              <p class="mainsubheading-global emailmarkating-subcintent">Get beautifully crafted templates that reflect
                your brand identity and drive better campaign performance, whether it's a newsletter HTML template or a
                product marketing email template.</p>

            </div>
            <div class="d-flex justify-content-start align-items-start gap-2">
              <img src="<?php echo $config['WEB_PATH'] ?>assets/images/RightSine.png">

              <p class="mainsubheading-global emailmarkating-subcintent">Ensure every email looks perfect on all screen
                sizes with fully responsive, mobile-first designs—our specialty includes creating responsive email
                templates and responsive newsletter templates optimized for all devices.</p>

            </div>
            <div class="d-flex justify-content-start align-items-start gap-2">
              <img src="<?php echo $config['WEB_PATH'] ?>assets/images/RightSine.png">

              <p class="mainsubheading-global emailmarkating-subcintent">Build trust and conversions with layouts
                optimized for readability, engagement, and clear call-to-actions.</p>

            </div>

            <button class="email-marketing-btn">Start Designing</button>

          </div>

        </div>
        <div class="col-lg-6  d-flex justify-content-center align-items-center scroll-section"
          data-animation="animate__fadeInUp" data-delay="0.2s">
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/email-marketing-img1.png" class="img-fluid">

        </div>
      </div>

      <div class="row mt-md-5 ">
        <div class="col-lg-6 d-flex justify-content-center align-items-center scroll-section"
          data-animation="animate__fadeInUp" data-delay="0s">
          <img src="<?php echo $config['WEB_PATH'] ?>assets/images/email-marketing-img2.png" class="img-fluid">

        </div>
        <div class="col-lg-6 scroll-section" data-animation="animate__fadeInUp" data-delay="0.2s">
          <p class="mainheading-global position-relative z-1">Responsive, <span
              class="mainheding-color">Pixel-Perfect</span><br class="d-none d-md-block"> Email Coding
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/ShopifyDevlopment.png"
              class="position-absolute img-fluid emailmarkating-pixelperfect-img service-img-header z-1"
              alt="Highlight Underline">
          </p>
          <p class="email-marketing-content emailmarkating-subcintent ">Our email marketing services include
            clean, responsive code that
            renders flawlessly across every major email platform.</p>



          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/RightSine.png">
            <p class="mainsubheading-global emailmarkating-subcintent  "> Code tested across Outlook, Gmail,
              Apple Mail, and more for
              perfect cross-client compatibility</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/RightSine.png">

            <p class="mainsubheading-global emailmarkating-subcintent  "> Responsive layouts built from scratch
              to work beautifully on all
              screen sizes and devices</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/RightSine.png">

            <p class="mainsubheading-global emailmarkating-subcintent  ">Lightweight, well-structured HTML ensures fast
              loading and optimal email deliverability—ideal for email advertising templates and more.</p>

          </div>

          <button class="email-marketing-btn">Start Colleborating</button>

        </div>

      </div>
    </div>

  </section>

  <div id="emailmarkating-service" class="scroll-section"></div>

  <section class="">
    <div class="container">
      <p class="mainheading-global text-center mt-5 position-relative z-1 scroll-section"
        data-animation="animate__fadeInUp" data-delay="0s">
        <span class="mainheding-color">Powerful Tools</span> to Enhance <br class="d-none d-lg-block">
        Every Email You Send
        <img src="<?php echo $config['WEB_PATH'] ?>assets/images/ShopifyDevlopment.png"
          class="position-absolute img-fluid email-markating-powerfooltool-img service-img-header z-1"
          alt="Highlight Underline">
      </p>

      <div class="row text-center text-lg-start gy-5">
        <!-- Column 1: Grow -->
        <div class="col-12 col-md-6 col-lg-3 scroll-section" data-animation="animate__fadeInUp" data-delay="0.2s">
          <div class="feature-icon py-3"><img src="<?php echo $config['WEB_PATH'] ?>assets/images/email-tools-img1.png" class="img-fluid"> </div>
          <div class="feature-heading">Grow</div>
          <p class="feature-text mb-4 pe-5">Reach your audience and turn subscribers into customers</p>
<hr>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Unlimited landing pages</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Unlimited opt-in forms</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Landing page & form templates</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Newsletter feed & website</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Custom domain</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">List growth reporting</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Creator Network</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Recommendations</p>

          </div>

        </div>

        <!-- Column 2: Connect -->
        <div class="col-12 col-md-6 col-lg-3 scroll-section" data-animation="animate__fadeInUp" data-delay="0.4s">
          <div class="feature-icon py-3"><img src="<?php echo $config['WEB_PATH'] ?>assets/images/email-tools-img2.png"> </div>
          <div class="feature-heading">Connect</div>
          <p class="feature-text mb-4 pe-5">Create deeper connections that drive real results</p>
<hr>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Unlimited email sends</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Custom email templates</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Email template library</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Deliver opt-in incentives</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Subscriber tagging</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">A/B split testing</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Conditional email content</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Resend unopened campaigns</p>
          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">In-email polls</p>

          </div>

        </div>

        <!-- Column 3: Design -->
        <div class="col-12 col-md-6 col-lg-3 scroll-section" data-animation="animate__fadeInUp" data-delay="0.6s">
          <div class="feature-icon py-3"><img src="<?php echo $config['WEB_PATH'] ?>assets/images/email-tools-img3.png"> </div>
          <div class="feature-heading">Design</div>
          <p class="feature-text mb-4 pe-5">Expertly crafted emails by top designers.
          </p>
          <hr>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Mobile-responsive templates</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Clean, pixel-perfect design</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Dark mode support</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Drag-and-drop components</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Branded layout options</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Live preview testing</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Custom HTML compatibility</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p class="mainsubheading-global">Device optimization</p>

          </div>


        </div>

        <!-- Column 4: Monetize -->
        <div class="col-12 col-md-6 col-lg-3 scroll-section" data-animation="animate__fadeInUp" data-delay="0.8s">
          <div class="feature-icon py-3"><img src="<?php echo $config['WEB_PATH'] ?>assets/images/email-tools-img4.png"></div>
          <div class="feature-heading">Monetize</div>
          <p class="feature-text mb-4 pe-5">Unlock new revenue opportunities from every campaign
            <hr>
          </p>

          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p>Sell digital products</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p>Run paid newsletters</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p>Offer recurring subscriptions</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p>Setup virtual tip jars</p>


          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p>Email ad placements</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p>Paid Recommendations</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p>Affiliate links integration</p>

          </div>
          <div class="d-flex justify-content-start align-items-start gap-2">
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/rigth-icon.png" class="img-fluid my-1">
            <p>Promo code campaigns</p>

          </div>

        </div>
      </div>

    </div>
    </div>
  </section>

  <div id="digitalmarketing-slider1" class="scroll-section"></div>

  <!-- <div id="emailmarkating-service" class="scroll-section"> </div> -->
  <section id="salesforce-voicethat" class="scroll-section">
    <div class="container py-5 voices-containt">
      <div class="row align-items-center">
        <div class="col-md-5 left-section">
          <p class="mainheading-global">
            <span class="mainheding-color">Voices</span> that Inspire
          </p>
          <p class="subtitle-contetn text-muted">
            Listen to the voices of our clients sharing their testimonials and
            feedback
          </p>
          <div class="d-flex justify-content-start align-items-center gap-3">
            <button id="customPrev" class="arrow-btn"><i class="bi bi-arrow-left"></i></button>
            <button id="customNext" class="arrow-btn"><i class="bi bi-arrow-right"></i></button>
          </div>
        </div>
        <div class="col-md-7">
          <div id="carouselExampleCaptions" class="carousel slide">
            <div class="carousel-indicators">
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0"
                class="active custom-gradient-border-box-slider-indicator" aria-current="true"
                aria-label="Slide 1"></button>
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                class="custom-gradient-border-box-slider-indicator" aria-label="Slide 2"></button>
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                class="custom-gradient-border-box-slider-indicator" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
              <div class="carousel-item text-center active">
                <div class="gradient-border-box mx-auto custom-gradient-border-box-width">
                  <div class="avatar-container mx-auto mb-3">
                    <img src="<?php echo $config['WEB_PATH'] ?>assets/images/voice-img.png" class="avatar123" alt="Avatar" />
                  </div>

                  <p class="testimonial-quote">
                    We needed someone to untangle our Salesforce mess—and Mavix
                    Tech delivered beyond expectations. They customized CRM.
                  </p>
                  <p class="testimonial-name">Alex Johnson</p>
                  <p class="testimonial-title">CTO at TechInsects</p>
                </div>
              </div>
              <div class="carousel-item text-center">
                <div class="gradient-border-box mx-auto custom-gradient-border-box-width">
                  <div class="avatar-container mx-auto mb-3">
                    <img src="<?php echo $config['WEB_PATH'] ?>assets/images/voice-img.png" class="avatar123" alt="Avatar" />
                  </div>

                  <p class="testimonial-quote">
                    We needed someone to untangle our Salesforce mess—and Mavix
                    Tech delivered beyond expectations. They customized CRM.
                  </p>
                  <p class="testimonial-name">Alex Johnson</p>
                  <p class="testimonial-title">CTO at TechInsects</p>
                </div>
              </div>
              <div class="carousel-item text-center">
                <div class="gradient-border-box mx-auto custom-gradient-border-box-width">
                  <div class="avatar-container mx-auto mb-3">
                    <img src="<?php echo $config['WEB_PATH'] ?>assets/images/voice-img.png" class="avatar123" alt="Avatar" />
                  </div>

                  <p class="testimonial-quote">
                    We needed someone to untangle our Salesforce mess—and Mavix
                    Tech delivered beyond expectations. They customized CRM.
                  </p>
                  <p class="testimonial-name">Alex Johnson</p>
                  <p class="testimonial-title">CTO at TechInsects</p>
                </div>
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
              data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
              data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="scroll-section">
    <div class="container my-5 mt-5 ">


      <div class="text-container mt-5 text-center position-relative">
        <p class="mainheading-global d-inline-block position-relative">

          <span class="highlight-wrapper position-relative d-inline-block">
            <span class="mainheding-color">Frequently</span>

            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/FrequentlyAsk Header.png"
              class="position-absolute img-fluid frequentlyask-heading-img service-img-header z-1"
              alt="Highlight Underline">
          </span>
          Asked Questions
        </p>
      </div>

      <p class="text-center text-muted mb-5">Find answers to common questions about our services, process, and
        expertise.</p>

      <div class="accordion frequently-main" id="faqAccordion">
        <div class="accordion-item border-0 shadow-sm mb-2">
          <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button mainsubheading-global   " type="button" data-bs-toggle="collapse"
              data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
              What are email marketing services?
            </button>
          </h2>
          <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body frequently-cont mainsubheading-global ">
              Email marketing services involve designing and developing professional email templates for promotional and
              transactional communication.
            </div>
          </div>
        </div>

        <div class="accordion-item border-0 shadow-sm mb-2">
          <h2 class="accordion-header" id="headingTwo">
            <button class="accordion-button mainsubheading-global  collapsed" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
              Do you create custom email designs?
            </button>
          </h2>
          <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body frequently-cont mainsubheading-global ">
              Yes, we design fully customized email template designs customized to your brand and campaign goals.
            </div>
          </div>
        </div>

        <div class="accordion-item border-0 shadow-sm mb-2">
          <h2 class="accordion-header" id="headingThree">
            <button class="accordion-button mainsubheading-global  collapsed" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
              Are your email templates mobile-friendly?
            </button>
          </h2>
          <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body frequently-cont mainsubheading-global ">
              Absolutely! All our templates are responsive email templates optimized for mobile devices.
            </div>
          </div>
        </div>

        <div class="accordion-item border-0 shadow-sm mb-2">
          <h2 class="accordion-header" id="headingFour">
            <button class="accordion-button mainsubheading-global  collapsed" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
              Can I use these templates on any platform?
            </button>
          </h2>
          <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body frequently-cont mainsubheading-global ">
              Yes, our templates are compatible with most major email platforms and created by expert html email
              designers.
            </div>
          </div>
        </div>

        <div class="accordion-item border-0 shadow-sm mb-2">
          <h2 class="accordion-header" id="headingFive">
            <button class="accordion-button mainsubheading-global  collapsed" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
              How long does it take to deliver a template?
            </button>
          </h2>
          <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body frequently-cont mainsubheading-global ">
              Typically, we deliver email templates within 3–5 business days.
            </div>
          </div>
        </div>


        <div class="accordion-item border-0 shadow-sm mb-2">
          <h2 class="accordion-header" id="headingSix">
            <button class="accordion-button mainsubheading-global  collapsed" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
              Can you match the template design to my brand?
            </button>
          </h2>
          <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body frequently-cont mainsubheading-global ">
              Yes, we ensure each email design aligns with your brand's look and feel.
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
