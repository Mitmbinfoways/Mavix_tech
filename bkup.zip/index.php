<?php
$config = include __DIR__ . '/config/config.php';


$page = $_GET['p'] ?? 'home';
include __DIR__ . '/templates/header.php';
$pageFile = __DIR__ . '/pages/' . basename($page) . '.php';


if (file_exists($pageFile)) {
    include $pageFile;
} else {
    echo "<h1>404 - Page Not Found</h1>";
}

include __DIR__ . '/templates/footer.php';