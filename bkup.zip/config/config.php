<?php
return [
    'site_name' => 'Mavix Tech',
    'contact_email' => 'you@example.com',
    'WEB_PATH'=>'/sagar/',
    'SITE_URL'=>'http://localhost/sagar/'
];