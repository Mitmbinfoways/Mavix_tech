<section class="contact-section1">
  <div class="container contactus-header scroll-section">
    <div class="row  text-start ">
      <div class="col-12 col-md-8 text-start">
        <p class="contact-us-heading">CONTACT US</p>
        <p class="mt-3 contact-us-heading-sub">Got a question?</p>
        <p class="subcontainet-global-header">Lorem ipsum is simply dummy text of the printing and typesetting
          industry.<br class="d-none d-md-block"> Lorem ipsum has been the industry's standard dummy text ever since the
          1500s.</p>
      </div>
    </div>
  </div>
</section>


<section class="contact-form-main scroll-section">
  <div class="container my-5">
    <div class="row">
      <!-- Contact Information Section -->
      <div class="col-md-4 contact-card">

        <div class="contact-info ">
          <h2 class="scroll-section" data-animation="animate__fadeInUp" data-delay="0.2s">Contact Information</h2>
          <p class="scroll-section" data-animation="animate__fadeInUp" data-delay="0.2s">Say something to start a live
            chat!</p>
          <div class="contact-details scroll-section" data-animation="animate__fadeInUp" data-delay="0.4s">
            <p><img src="<?php echo $config['WEB_PATH'] ?>assets/images/Callbtn.png" alt="Callbtn"> +1012 3456 789</p>
            <p><img src="<?php echo $config['WEB_PATH'] ?>assets/images/Gmailbtn.png" alt="Gmailbtn"> demo@gmail.com</p>
            <p><img src="<?php echo $config['WEB_PATH'] ?>assets/images/Locationbtn.png" alt="Locationbtn"> 132 Dartmouth Street Boston,
              Massachusetts 02156 United
              States
            </p>
          </div>
          <div class="social-icons">




            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Twitorebtn.png" alt="Callbtn" class="social-icon-contact-form">

            <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg" class="social-icon-contact-form">
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M4.45218 0.045C5.25998 0.00818181 5.51754 0 7.57525 0C9.63296 0 9.89052 0.00886363 10.6976 0.045C11.5047 0.0811364 12.0557 0.208636 12.5377 0.393409C13.0425 0.582273 13.5005 0.8775 13.8792 1.25932C14.2649 1.63364 14.5624 2.08636 14.7525 2.58682C14.9398 3.06409 15.0679 3.60955 15.105 4.40727C15.1422 5.20841 15.1505 5.46341 15.1505 7.5C15.1505 9.53727 15.1415 9.79227 15.105 10.592C15.0686 11.3898 14.9398 11.9352 14.7525 12.4125C14.5624 12.913 14.2644 13.3665 13.8792 13.7414C13.5005 14.1232 13.0425 14.4177 12.5377 14.6059C12.0557 14.7914 11.5047 14.9182 10.699 14.955C9.89052 14.9918 9.63296 15 7.57525 15C5.51754 15 5.25998 14.9911 4.45218 14.955C3.64645 14.9189 3.09552 14.7914 2.61346 14.6059C2.10793 14.4177 1.6499 14.1227 1.27126 13.7414C0.885877 13.3668 0.587643 12.9136 0.397356 12.4132C0.21073 11.9359 0.0826391 11.3905 0.0454515 10.5927C0.0082639 9.79159 0 9.53659 0 7.5C0 5.46273 0.00895256 5.20773 0.0454515 4.40864C0.0819504 3.60955 0.21073 3.06409 0.397356 2.58682C0.587924 2.08642 0.886386 1.63317 1.27195 1.25864C1.65006 0.87716 2.10762 0.581893 2.61277 0.393409C3.09483 0.208636 3.64576 0.0818182 4.45149 0.045H4.45218ZM10.6363 1.395C9.8375 1.35886 9.59784 1.35136 7.57525 1.35136C5.55266 1.35136 5.31301 1.35886 4.51416 1.395C3.77523 1.42841 3.37443 1.55045 3.10723 1.65341C2.75395 1.78977 2.50121 1.95136 2.23608 2.21386C1.98475 2.45594 1.79133 2.75065 1.67 3.07636C1.56601 3.34091 1.44274 3.73773 1.409 4.46932C1.3725 5.26023 1.36492 5.4975 1.36492 7.5C1.36492 9.5025 1.3725 9.73977 1.409 10.5307C1.44274 11.2623 1.56601 11.6591 1.67 11.9236C1.7912 12.2489 1.98472 12.5441 2.23608 12.7861C2.48055 13.035 2.77874 13.2266 3.10723 13.3466C3.37443 13.4495 3.77523 13.5716 4.51416 13.605C5.31301 13.6411 5.55197 13.6486 7.57525 13.6486C9.59853 13.6486 9.8375 13.6411 10.6363 13.605C11.3753 13.5716 11.7761 13.4495 12.0433 13.3466C12.3966 13.2102 12.6493 13.0486 12.9144 12.7861C13.1658 12.5441 13.3593 12.2489 13.4805 11.9236C13.5845 11.6591 13.7078 11.2623 13.7415 10.5307C13.778 9.73977 13.7856 9.5025 13.7856 7.5C13.7856 5.4975 13.778 5.26023 13.7415 4.46932C13.7078 3.73773 13.5845 3.34091 13.4805 3.07636C13.3428 2.72659 13.1796 2.47636 12.9144 2.21386C12.6699 1.96505 12.3722 1.77355 12.0433 1.65341C11.7761 1.55045 11.3753 1.42841 10.6363 1.395V1.395ZM6.60768 9.81205C7.14805 10.0347 7.74974 10.0648 8.31 9.89708C8.87026 9.72936 9.35433 9.37426 9.67952 8.89244C10.0047 8.41062 10.1509 7.83196 10.093 7.2553C10.0352 6.67864 9.7769 6.13975 9.36232 5.73068C9.09804 5.46919 8.77848 5.26896 8.42666 5.14442C8.07484 5.01987 7.6995 4.97411 7.32767 5.01042C6.95584 5.04673 6.59677 5.16421 6.2763 5.35441C5.95584 5.5446 5.68195 5.80278 5.47436 6.11035C5.26677 6.41793 5.13064 6.76724 5.07577 7.13316C5.02091 7.49907 5.04866 7.87247 5.15705 8.22649C5.26544 8.5805 5.45176 8.90632 5.70259 9.18049C5.95343 9.45466 6.26255 9.67035 6.60768 9.81205ZM4.82199 4.77409C5.18355 4.41612 5.61279 4.13216 6.0852 3.93843C6.5576 3.7447 7.06392 3.64498 7.57525 3.64498C8.08658 3.64498 8.5929 3.7447 9.0653 3.93843C9.53771 4.13216 9.96695 4.41612 10.3285 4.77409C10.6901 5.13206 10.9769 5.55704 11.1726 6.02475C11.3682 6.49246 11.4689 6.99375 11.4689 7.5C11.4689 8.00625 11.3682 8.50754 11.1726 8.97525C10.9769 9.44296 10.6901 9.86794 10.3285 10.2259C9.5983 10.9489 8.60792 11.355 7.57525 11.355C6.54258 11.355 5.5522 10.9489 4.82199 10.2259C4.09178 9.50295 3.68155 8.52241 3.68155 7.5C3.68155 6.47759 4.09178 5.49705 4.82199 4.77409V4.77409ZM12.3325 4.21909C12.4221 4.13541 12.4938 4.03478 12.5434 3.92316C12.5931 3.81155 12.6195 3.69121 12.6213 3.56927C12.6231 3.44733 12.6002 3.32628 12.5539 3.21328C12.5076 3.10028 12.4389 2.99762 12.3518 2.91139C12.2647 2.82516 12.161 2.75711 12.0468 2.71126C11.9327 2.66542 11.8104 2.64271 11.6873 2.64449C11.5641 2.64627 11.4426 2.67249 11.3298 2.72161C11.2171 2.77073 11.1155 2.84175 11.0309 2.93045C10.8666 3.10297 10.7766 3.33213 10.7801 3.56927C10.7836 3.80641 10.8803 4.03287 11.0496 4.20057C11.219 4.36828 11.4478 4.46402 11.6873 4.46748C11.9268 4.47093 12.1583 4.38183 12.3325 4.21909V4.21909Z"
                fill="white" />
            </svg>
            <img src="<?php echo $config['WEB_PATH'] ?>assets/images/Discardbtn.png" alt="Locationbtn">

          </div>
          <div class="circle-bg scroll-section"></div>
          <div class="circle-bg circle-bg-sm scroll-section"></div>
        </div>
      </div>
      <!-- Form Section -->
      <div class="col-md-8 form-section">
        <div class="container my-5">
          <form id="contactForm" class="scroll-section" data-animation="animate__fadeInUp" data-delay="0.2s ">
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="firstName">First Name</label>
                <input type="text" class="form-control" id="firstName">
                <span class="text-danger d-none" id="firstNameError">First name is required</span>
              </div>
              <div class="col-md-6">
                <label for="lastName">Last Name</label>
                <input type="text" class="form-control" id="lastName">
                <span class="text-danger d-none" id="lastNameError">Last name is required</span>
              </div>
            </div>

            <div class="row mb-3">
              <div class="col-md-6">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email">
                <span class="text-danger d-none" id="emailError">Email is required</span>
              </div>
              <div class="col-md-6">
                <label for="phone">Phone Number</label>
                <input type="tel" class="form-control" id="phone">
                <span class="text-danger d-none" id="phoneError">Phone number is required</span>
              </div>
            </div>

            <div class="mb-3">
              <p class="mb-2">Select Subject</p>
              <div class="form-check form-check-inline">
                <input class="form-check-input contact-check-input" type="checkbox" name="subject" id="general"
                  value="general">
                <label class="form-check-label" for="general">General Enquiry</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input contact-check-input" type="checkbox" name="subject" id="sales"
                  value="sales">
                <label class="form-check-label" for="sales">Technical Support</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input contact-check-input" type="checkbox" name="subject" id="support"
                  value="support">
                <label class="form-check-label" for="support">Billing Inquiry</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input contact-check-input" type="checkbox" name="subject" id="support"
                  value="support">
                <label class="form-check-label" for="support">Other</label>
              </div>


              <span class="text-danger d-none" id="subjectError">Please select at least one subject</span>
            </div>

            <div class="mb-3">
              <label for="message">Message</label>
              <textarea class="form-control" id="message" rows="1" placeholder="Write your message.."></textarea>
              <span class="text-danger d-none" id="messageError">Message is required</span>
            </div>

            <div class="text-end">
              <button type="submit" class="btn btn-primary">Send Message</button>
              <img src="<?php echo $config['WEB_PATH'] ?>assets/images/contactus-arrow.png" alt="abc" class="position-absolute contact-header-arrow" />
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>