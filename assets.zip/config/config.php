<?php
return [
    'site_name' => 'Mavix Tech',
    'contact_email' => 'you@example.com',
    'WEB_PATH'=>'/staging/',
    'SITE_URL'=>'https://mavixtech.com/staging/'
];